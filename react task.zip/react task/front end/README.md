# Zen3 company
developed  an web application to create, read, delete and update list of workitems for a project. Used window.localStorage to persist the data.

i would suggest you to follow this steps
1.  open the task 
2.  run npm install command in your system
3.  Run npm start command in your system
