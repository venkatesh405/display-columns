import React from 'react';
import logo from './logo.svg';
import './App.css';
import employeeTable from './employeeTable';

function App() {
  
  return (
    <div className="App">
        <employeeTable />
    </div>
  );
}

export default App;
